// grillfest_backend/index.js
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const { v4: uuidv4 } = require("uuid");
const nodemailer = require("nodemailer");
const QRCode = require("qrcode");
const { Pool } = require("pg");
require("dotenv").config();

const app = express();
const port = process.env.PORT || 3001;

// PostgreSQL pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});

app.use(cors());
app.use(bodyParser.json());

// Email transporter (example with Gmail)
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

// Create table if not exists
const createTable = async () => {
  await pool.query(\`
    CREATE TABLE IF NOT EXISTS registrations (
      id UUID PRIMARY KEY,
      student_id TEXT NOT NULL,
      email TEXT,
      meals JSONB NOT NULL,
      drinks JSONB NOT NULL,
      total_price INTEGER,
      timestamp TIMESTAMP
    );
  \`);
};
createTable();

// POST: Register for Grillfest
app.post("/register", async (req, res) => {
  const { studentId, meals, drinks, email } = req.body;
  if (!studentId) return res.status(400).json({ error: "Student ID is required." });

  const id = uuidv4();
  const totalPrice =
    Object.values(meals).filter(Boolean).length * 2 +
    (drinks.beer || 0) * 1 +
    (drinks.spezi || 0) * 1;

  try {
    await pool.query(
      \`INSERT INTO registrations (id, student_id, email, meals, drinks, total_price, timestamp)
       VALUES ($1, $2, $3, $4, $5, $6, $7)\`,
      [id, studentId, email, meals, drinks, totalPrice, new Date().toISOString()]
    );

    let qrImageUrl = null;
    if (email) {
      const qrData = \`ID: \${id}\nStudent ID: \${studentId}\nTotal: \${totalPrice} €\`;
      qrImageUrl = await QRCode.toDataURL(qrData);

      await transporter.sendMail({
        from: process.env.EMAIL_USER,
        to: email,
        subject: "Grillfest Registration Confirmation",
        html: \`
          <p>Thank you for registering!</p>
          <p><strong>Meals:</strong> \${JSON.stringify(meals)}</p>
          <p><strong>Drinks:</strong> \${JSON.stringify(drinks)}</p>
          <p><strong>Total Price:</strong> \${totalPrice} €</p>
          <p><strong>QR Code for check-in:</strong></p>
          <img src="\${qrImageUrl}" alt="QR Code"/>
        \`,
      });
    }

    res.status(200).json({ success: true, id, totalPrice, qrImageUrl });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Database error" });
  }
});

// GET: All registrations (for admin)
app.get("/admin/registrations", async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM registrations");
    res.status(200).json(result.rows);
  } catch (err) {
    res.status(500).json({ error: "Database error" });
  }
});

app.listen(port, () => {
  console.log(\`Grillfest backend running on port \${port}\`);
});
