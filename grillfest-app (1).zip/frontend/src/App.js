// src/App.js
import React, { useState } from "react";

function App() {
  const [formData, setFormData] = useState({
    studentId: "",
    email: "",
    meals: {
      chicken: false,
      bratwurst: false,
      falafel: false,
      salad: false,
    },
    drinks: {
      beer: 0,
      spezi: 0,
    },
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (name in formData.meals) {
      setFormData({
        ...formData,
        meals: { ...formData.meals, [name]: checked },
      });
    } else if (name in formData.drinks) {
      setFormData({
        ...formData,
        drinks: { ...formData.drinks, [name]: parseInt(value) },
      });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch("https://grillfest-backend.onrender.com/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (data.success) {
        alert(`Registration complete! Total: €${data.totalPrice}`);
      } else {
        alert("Error: " + data.error);
      }
    } catch (err) {
      alert("Something went wrong.");
    }
  };

  return (
    <div className="p-6 max-w-md mx-auto">
      <h1 className="text-xl font-bold mb-4">Grillfest Registration</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input name="studentId" required placeholder="Student ID" value={formData.studentId} onChange={handleChange} className="w-full p-2 border" />
        <input name="email" type="email" placeholder="Email (for confirmation)" value={formData.email} onChange={handleChange} className="w-full p-2 border" />

        <div>
          <p className="font-semibold">Meals (€2 each)</p>
          {Object.keys(formData.meals).map((meal) => (
            <label key={meal} className="block">
              <input
                type="checkbox"
                name={meal}
                checked={formData.meals[meal]}
                onChange={handleChange}
              /> {meal.charAt(0).toUpperCase() + meal.slice(1)}
            </label>
          ))}
        </div>

        <div>
          <p className="font-semibold">Drinks (€1 each)</p>
          <label className="block">Beer: <input type="number" name="beer" value={formData.drinks.beer} onChange={handleChange} min="0" /></label>
          <label className="block">Spezi: <input type="number" name="spezi" value={formData.drinks.spezi} onChange={handleChange} min="0" /></label>
        </div>

        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">Register</button>
      </form>
    </div>
  );
}

export default App;
